# -*- coding: utf-8 -*-

# -- cuidar el orden al momento de crear o modificar los modelos
#    debido a las relaciones.

from . import grados_estudio
from . import nombre_cuentas_email
from . import autos
from . import persona
from . import calendario

