# -*- coding: utf-8 -*-

from . import herencia_stock